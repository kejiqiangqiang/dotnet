﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;

namespace MvcApplication1.Controllers
{
    public class HttpUploadModule : IHttpModule
    {
        public HttpUploadModule()
        {

        }
        public void Init(HttpApplication application)
        {
            //订阅事件
            application.BeginRequest += new EventHandler(this.Application_BeginRequest);
        }
        public void Dispose()
        {
        }

        private void Application_BeginRequest(Object sender, EventArgs e)
        {
            #region 初始化
            HttpApplication mApplication = sender as HttpApplication;
            IServiceProvider mProvider = HttpContext.Current;
            HttpWorkerRequest mWorkRequest = (HttpWorkerRequest)mProvider.GetService(typeof(HttpWorkerRequest));
            HttpContext context = ((HttpApplication)sender).Context;
            #endregion

            string mContentType = mApplication.Request.ContentType;
            if (mWorkRequest.HasEntityBody() && IsUploadRequest(context.Request))
            {
                //创建空文件接受传入的主题二进制流
                FileStream fs = new FileStream(
                        context.Server.MapPath("~/Content/" + DateTime.Now.ToString("HHmmss") + ".zip"),
                        FileMode.CreateNew);

                #region 获取分隔符和位置
                string mBoundaryStr =
                    mContentType.Substring(mContentType.IndexOf("boundary=", 0, StringComparison.OrdinalIgnoreCase) + 9);
                byte[] mBoundaryData = Encoding.ASCII.GetBytes("\r\n--" + mBoundaryStr);
                //页面上file的name属性
                byte[] mTmpData = Encoding.ASCII.GetBytes("name=\"file\"");
                byte[] mSepeatar = Encoding.ASCII.GetBytes("\r\n\r\n");
                byte[] readData = mWorkRequest.GetPreloadedEntityBody();
                #endregion
                int mPreLen = readData.Length;
                MemoryStream cxp = new MemoryStream(); //当前已读取内容的

                cxp.Write(readData, 0, mPreLen);

                if (!mWorkRequest.IsEntireEntityBodyIsPreloaded())
                {
                    #region 初始化
                    
                    bool fileContentReadOk = true;      //是否继续读取
                    int iSize = 655350;
                    byte[] buffer = new byte[iSize];

                    int readSize = mWorkRequest.ReadEntityBody(buffer, iSize);
                    #endregion

                    #region 处理数据节

                    //此时readSize=0的话与进入时的逻辑判断冲突,没加异常处理。
                    while (fileContentReadOk)
                    {
                        cxp.Write(buffer, 0, readSize);
                        readData = cxp.ToArray();

                        #region
                        //name=FileUpload的文件头是否已经全部读取
                        int mTmpStart = TransactData(readData, mTmpData);
                        if (mTmpStart == -1)
                        {
                            //继续读取
                            readSize = mWorkRequest.ReadEntityBody(buffer, iSize);
                            continue;
                        }
                        //找到name=FileUpload的实体值的起始位置
                        int mTmpEnd = TransactData(readData, mSepeatar, mTmpStart);
                        if (mTmpEnd == -1)
                        {
                            readSize = mWorkRequest.ReadEntityBody(buffer, iSize);
                            continue;
                        }
                        #endregion

                        #region 读取文件内容并实体值中移除

                        int mValueLoadAll = TransactData(readData, mBoundaryData, mTmpEnd);
                        if (mValueLoadAll == -1)
                        {
                            //为了检测“分隔符是否存在跨Entity的现象
                            readSize = mWorkRequest.ReadEntityBody(buffer, iSize);
                            if (readSize == 0)
                            {
                                throw new Exception("非法的RFC数据实体定义！");
                            }
                            int len = mBoundaryData.Length;
                            int mBoundaryLen = readSize > len ? len : readSize;
                            int ks = readData.Length - mTmpEnd + mBoundaryLen;
                            //在\r\n\r\n之后的内空
                            byte[] suffix = new byte[ks];
                            if (readData.Length - mTmpEnd > mTmpEnd)
                            {
                                Array.Copy(readData, mTmpEnd, suffix, 0, mTmpEnd);
                            }
                            else
                            {
                                Array.Copy(readData, mTmpEnd, suffix, 0, readData.Length - mTmpEnd);
                            }
                            if (suffix.Length < mTmpEnd + mBoundaryLen)
                            {
                                Array.Copy(buffer, 0, suffix, 0, mBoundaryLen);
                            }
                            else
                            {
                                Array.Copy(buffer, 0, suffix, mTmpEnd, mBoundaryLen);
                            }
                            int hasBoundary = TransactData(suffix, mBoundaryData);
                            if (hasBoundary == -1)
                            {
                                //不跨边界
                                byte[] fileContent = new byte[readData.Length - mTmpEnd];
                                Array.Copy(readData, mTmpEnd, fileContent, 0, fileContent.Length);
                                //上传文件片断
                                fs.Write(fileContent, 0, fileContent.Length);
                                cxp.Close();
                                cxp = new MemoryStream();
                                cxp.Write(readData, 0, mTmpEnd);
                            }
                        }
                        else
                        {
                            fileContentReadOk = false;
                            int len = mValueLoadAll - mTmpEnd - mBoundaryData.Length;
                            byte[] cn = new byte[len];
                            Array.Copy(readData, mTmpEnd, cn, 0, len);
                            //上传最后一个文件段
                            fs.Write(cn, 0, cn.Length);
                        }
                        #endregion
                    }
                    #endregion
                }
                else
                {
                    //没加xxx==-1的判断，最好是加上。
                    //查找name="FileUpload1"的起始位置
                    int mTmpStart = TransactData(readData, mTmpData);

                    //实体值的起始位置
                    int mTmpEnd = TransactData(readData, mSepeatar, mTmpStart);
                    //实体值的结束位置
                    int mValueEnd = TransactData(readData, mBoundaryData, mTmpEnd);
                    int len = mValueEnd - mTmpEnd - mBoundaryData.Length;
                    byte[] cn = new byte[len];
                    Array.Copy(readData, mTmpEnd, cn, 0, len);
                    //上传
                    fs.Write(cn, 0, cn.Length);
                    cxp.Close();
                }
                fs.Flush();
                fs.Close();
            }
        }

        public static int TransactData(byte[] readData, byte[] mBoundary)
        {
            return TransactData(readData, mBoundary, 0);
        }
        public static int TransactData(byte[] readData, byte[] mBoundary, int iStartIndex)
        {
            int iBodudaryIndex = 0;
            int iBoundaryLen = mBoundary.Length;
            int iIndex = iStartIndex;
            int iLen = readData.Length;
            bool bEnd = false;
            while (iIndex < iLen && (bEnd == false))
            {
                if (mBoundary[iBodudaryIndex] == readData[iIndex])
                {
                    iBodudaryIndex++;
                }
                else
                {
                    iBodudaryIndex = 0;
                }
                if (iBodudaryIndex == iBoundaryLen)
                {
                    bEnd = true;
                }
                iIndex++;
            }
            if (bEnd)
            {

                return iIndex;
            }
            else
            {
                return -1;
            }
        }
        /// <summary>
        /// 是否为附件上传
        /// 判断的根据是ContentType中有无multipart/form-data
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        private bool IsUploadRequest(HttpRequest request)
        {
            return StringStartsWithAnotherIgnoreCase(request.ContentType, "multipart/form-data");
        }
        private static bool StringStartsWithAnotherIgnoreCase(string s1, string s2)
        {
            return (string.Compare(s1, 0, s2, 0, s2.Length, true, CultureInfo.InvariantCulture) == 0);
        }
    }
}
