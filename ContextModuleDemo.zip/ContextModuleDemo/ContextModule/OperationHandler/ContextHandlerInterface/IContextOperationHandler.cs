﻿/***
 * author:深度训练
 * blog:http://wangqingpei557.blog.51cto.com/
 * **/
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ContextModule
{
    /// <summary>
    /// 上下文操作管理接口
    /// </summary>
    public interface IContextOperationHandler
    {
        /// <summary>
        /// 开始上下文处理
        /// </summary>
        /// <param name="contextmethod">CRL目前正在执行的上下文方法的信息。
        /// 可以通过ContextMethodInfo实例获取方法详细信息。</param>
        ///<param name="paramarray">参数数组</param>
        object Operation(ContextMethodInfo contextmethod, params object[] paramarray);
    }
}
