﻿/***
 * author:深度训练
 * blog:http://wangqingpei557.blog.51cto.com/
 * **/
using System;
using System.Collections.Generic;
using System.Text;

namespace ContextModule
{
    /// <summary>
    /// 上下文性能分析特性类。
    /// 该类专门用来计算一些方法的处理时间，便于分析方法的执行性能。
    /// </summary>
    public class ContextCapabilityHandler : ContextOperationBaseAttribute, IContextOperationHandler
    {
        public override object Operation(ContextMethodInfo contextmethod, params object[] paramarray)
        {
            throw new NotImplementedException();
        }
    }
}
