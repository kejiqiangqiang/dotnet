﻿/***
 * author:深度训练
 * blog:http://wangqingpei557.blog.51cto.com/
 * **/
using System;
using System.Collections.Generic;
using System.Text;

namespace ContextModule
{
    /// <summary>
    /// 上下文操作日志记录特性类。
    /// 该类专门用来记录对特性方法的操作日志，可以通过上层上下文对象接口进行扩展记录方式。
    /// </summary>
    [AttributeUsage(AttributeTargets.All, AllowMultiple = false)]
    public class ContextLogHandler : ContextOperationBaseAttribute, IContextOperationHandler
    {
        public override object Operation(ContextMethodInfo contextmethod, params object[] paramarray)
        {
            string logstr = string.Format("记录日志：调用的方法为：{1}",
                this.OperationSort, contextmethod.MethodInfo.DeclaringType.FullName + "." + contextmethod.MethodInfo.Name);
            Console.WriteLine(logstr);
            if (this.NextOperation == null)//如果该过滤器是最后一个过滤器，那么将执行动态方法的调用。
            {
                return contextmethod.MethodInfo.Invoke(contextmethod.PostObject, paramarray);
            }
            return null;
        }
    }
}
