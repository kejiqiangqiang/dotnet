﻿/***
 * author:深度训练
 * blog:http://wangqingpei557.blog.51cto.com/
 * **/
using System;
using System.Collections.Generic;
using System.Text;

namespace ContextModule
{
    /// <summary>
    /// 管理上下文安全特性类。
    /// 指定方法的调用者必须具备安全认证，认证方式可以通过接口扩展。注意：这里的安全与.NET内部安全是两个概念。
    /// </summary>
    public class ContextSecurityHanlder : ContextOperationBaseAttribute, IContextOperationHandler
    {
        public override object Operation(ContextMethodInfo contextmethod, params object[] paramarray)
        {
            Console.WriteLine("调用授权：请输入用户凭据，才能对方法{0}进行调用。", contextmethod.MethodInfo.Name);
            string key = Console.ReadLine();
            if (key == "yes")
            {
                object result = contextmethod.MethodInfo.Invoke(contextmethod.PostObject, paramarray);
                return result;
            }
            return null;
        }
    }
}
