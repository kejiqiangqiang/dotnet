﻿/***
 * author:深度训练
 * blog:http://wangqingpei557.blog.51cto.com/
 * **/
using System;
using System.Collections.Generic;
using System.Text;

namespace ContextModule
{
    /// <summary>
    /// 上下文异常处理特性类,可以作用于类、方法。
    /// 通过使用该特性能在未知的情况下动态捕获异常,并使用人性化的方式作出提示。
    /// </summary>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class ContextExceptionHandler : ContextOperationBaseAttribute, IContextOperationHandler
    {
        public override object Operation(ContextMethodInfo contextmethod, params object[] paramarray)
        {
            try
            {
                contextmethod.IsPost = true;//拦截过滤器
                return contextmethod.MethodInfo.Invoke(contextmethod.PostObject, paramarray);
            }
            catch (Exception err)
            {
                string logstr = string.Format("过滤器编号：{0}\t调用的方法为：{1}",
               this.OperationSort, contextmethod.MethodInfo.DeclaringType.FullName + "." + contextmethod.MethodInfo.Name);
                Console.WriteLine(logstr + err.InnerException.Message.ToString());
                return null;
            }
        }
    }
}
