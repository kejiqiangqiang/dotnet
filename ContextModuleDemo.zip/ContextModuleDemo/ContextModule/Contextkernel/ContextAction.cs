﻿/***
 * author:深度训练
 * blog:http://wangqingpei557.blog.51cto.com/
 * **/
using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace ContextModule
{
    /// <summary>
    /// 面向上下文的操作类。
    /// 对上下文发起的方法调用需要通过该基类进行调用才能让我们的扩展点使用成为可能。
    /// </summary>
    public static class ContextAction
    {
        /// <summary>
        /// 在面向上下文的环境中进行方法的调用。
        /// </summary>
        /// <typeparam name="PostObjectType">调用的上下文绑定对象类型</typeparam>
        /// <typeparam name="ResultType">方法的返回类型</typeparam>
        /// <param name="post">调用的上下文绑定对象的实例</param>
        /// <param name="method">方法的信息对象MethodInfo,通过Oject.GetContextMethodInfo方法自动获取。</param>
        /// <param name="paramarray">方法的有序参数集合</param>
        /// <returns>ResultType泛型类型指定的返回实例</returns>
        public static ResultType PostMethod<PostObjectType, ResultType>(PostObjectType post, MethodInfo method, params object[] paramarray)
            where PostObjectType : ContextModuleBaseObject<PostObjectType>
        {
            _LockPostObejctIsEveningBound<PostObjectType>(post);
            string key = string.Format("{0}.{1}", method.DeclaringType.FullName, method.Name);
            if (!ContextRuntime.CurrentContextRuntime.FilterMap.ContainsKey(key))
            {
                throw new Exception(string.Format("方法{0}未经过上下文进行管理。", key));
            }
            ContextMethodInfo contextmethod = new ContextMethodInfo(method, post);
            return ContextRuntime.CurrentContextRuntime.FilterMap[key].ResultAction<ResultType>(contextmethod, paramarray);
        }
        /// <summary>
        /// 检查调用实例类是否属于后期绑定。
        /// 通过使用ContextModule.ContextEveningBound(IsEvening = true)方式指定后期绑定上下文。
        /// </summary>
        private static void _LockPostObejctIsEveningBound<PostObjectType>(PostObjectType post)
            where PostObjectType : ContextModuleBaseObject<PostObjectType>
        {
            ContextModuleBaseObject<PostObjectType> contextclass = post as ContextModuleBaseObject<PostObjectType>;
            if (contextclass._IsEvening)
                contextclass._EveningBoundChildClass<PostObjectType>();
        }
    }
}
