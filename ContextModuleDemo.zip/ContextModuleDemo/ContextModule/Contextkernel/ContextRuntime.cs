﻿/***
 * author:深度训练
 * blog:http://wangqingpei557.blog.51cto.com/
 * **/
using System;
using System.Collections.Generic;
using System.Text;

namespace ContextModule
{
    /// <summary>
    /// 上下文运行时环境。
    /// 上下文逻辑运行时环境，环境中的功能都是可以通过附加进来的。
    /// </summary>
    public class ContextRuntime : IDisposable
    {
        #region IDisposable成员
        void IDisposable.Dispose()
        {
            _currentContextRuntime = null;
        }
        #endregion

        protected ContextRuntime() { }
        private DateTime _initTime = DateTime.Now;
        /// <summary>
        /// 获取运行时创建上下文的时间
        /// </summary>
        public virtual DateTime InitTime { get { return _initTime; } }
        private Dictionary<object, object> _runTimeResource = new Dictionary<object, object>();
        private ContextFilterHandlerMap _filterMap = new ContextFilterHandlerMap();
        /// <summary>
        /// 获取上下文中的方法、类过滤器映射表
        /// </summary>
        public ContextFilterHandlerMap FilterMap { get { return _filterMap; } }
        private Guid _initPrimaryKey = Guid.NewGuid();
        /// <summary>
        /// 获取运行时创建上下文的唯一标识
        /// </summary>
        public virtual Guid InitPrimaryKey { get { return _initPrimaryKey; } }
        /// <summary>
        /// 获取上下文共享区域中的数据
        /// </summary>
        /// <param name="key">数据Key</param>
        /// <returns>object数据对象</returns>
        public virtual object GetValue(object key)
        {
            return _runTimeResource[key];
        }
        /// <summary>
        /// 设置上下文共享区域中的数据
        /// </summary>
        /// <param name="key">数据Key</param>
        /// <param name="value">要设置的数据对象</param>
        public virtual void SetValue(object key, object value)
        {
            _runTimeResource[key] = value;
        }

        [ThreadStatic]
        private static ContextRuntime _currentContextRuntime;
        /// <summary>
        /// 获取当前上下文运行时对象.
        /// </summary>
        public static ContextRuntime CurrentContextRuntime { get { return _currentContextRuntime; } }
        /// <summary>
        /// 开始运行时上下文
        /// </summary>
        /// <returns>ContextRuntime</returns>
        public static ContextRuntime BeginContextRuntime()
        {
            //可以通过配置文件配置上下文运行时环境的参数。这里只是实现简单的模拟。
            _currentContextRuntime = new ContextRuntime();
            return _currentContextRuntime;
        }
    }
}
