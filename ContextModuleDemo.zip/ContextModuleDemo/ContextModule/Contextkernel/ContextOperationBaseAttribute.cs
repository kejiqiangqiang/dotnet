﻿/***
 * author:深度训练
 * blog:http://wangqingpei557.blog.51cto.com/
 * **/
using System;
using System.Collections.Generic;
using System.Text;

namespace ContextModule
{
    /// <summary>
    /// 上下文操作动作特性化基类。
    /// 所有对上下文中的类、方法的过滤操作都必须继承此类。
    /// </summary>
    public abstract class ContextOperationBaseAttribute : Attribute, IContextOperationHandler
    {
        /// <summary>
        /// 过滤器的处理顺序，从小到大的方式进行处理。
        /// </summary>
        public int OperationSort { get; set; }
        /// <summary>
        /// 下一次过滤操作类
        /// </summary>
        internal ContextOperationBaseAttribute NextOperation { get; set; }
        /// <summary>
        /// 开始处理过滤对象
        /// </summary>
        /// <typeparam name="Result">方法的返回值类型</typeparam>
        /// <param name="actionmethod">调用的方法包装</param>
        /// <param name="paramarray">方法的有序参数</param>
        /// <returns></returns>
        public virtual Result ResultAction<Result>(ContextMethodInfo actionmethod, params object[] paramarray)
        {
            object result = null;
            if (!actionmethod.IsPost)
            {
                result = (this as IContextOperationHandler).Operation(actionmethod, paramarray);
                if (this.NextOperation != null)
                    return this.NextOperation.ResultAction<Result>(actionmethod, paramarray);
            }
            if (result != null)
                return (Result)result;
            return default(Result);
        }


        public abstract object Operation(ContextMethodInfo contextmethod, params object[] paramarray);
    }
}
