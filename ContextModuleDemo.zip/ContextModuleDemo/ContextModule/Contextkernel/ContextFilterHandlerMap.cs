﻿/***
 * author:深度训练
 * blog:http://wangqingpei557.blog.51cto.com/
 * **/
using System;
using System.Collections.Generic;
using System.Text;

namespace ContextModule
{
    /// <summary>
    /// 特定于上下文的过滤器映射表。
    /// 上下文中的任何方法如果需要进行上下文管理的，则使用ContextModule.ContextOperationBaseAttribute特性派生类进行管理。
    /// 所有附加于方法、类上的特性管理类都将被映射到ContextModule.ContextFilterHandlerMap实例中。
    /// </summary>
    public class ContextFilterHandlerMap : Dictionary<string, ContextOperationBaseAttribute>
    {
        public ContextFilterHandlerMap() { }
        /// <summary>
        /// 获取方法对应的过滤器处理特性
        /// </summary>
        /// <param name="mapname">映射Key</param>
        /// <returns>ContextOperationBaseAttribute特性实例</returns>
        public ContextOperationBaseAttribute MapOperation(string mapname)
        {
            return this[mapname];
        }
        /// <summary>
        /// 设置过滤器与特定方法的映射
        /// </summary>
        /// <param name="mapname">映射Key</param>
        /// <param name="operationlist">过滤器特性基类ContextOperationBaseAttribute</param>
        public void MapOperation(string mapname, ContextOperationBaseAttribute operationlist)
        {
            this.Add(mapname, operationlist);
        }
    }
}
