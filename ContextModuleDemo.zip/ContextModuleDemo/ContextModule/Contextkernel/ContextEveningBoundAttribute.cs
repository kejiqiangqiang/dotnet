﻿/***
 * author:深度训练
 * blog:http://wangqingpei557.blog.51cto.com/
 * **/
using System;
using System.Collections.Generic;
using System.Text;

namespace ContextModule
{
    /// <summary>
    /// 确定设置类是否需要后期动态绑定到上下文。
    /// 使用该特性的类将是上下文活跃的，只有在使用的时候才确定当前上下文。
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = true)]
    public class ContextEveningBoundAttribute : Attribute
    {
        public ContextEveningBoundAttribute() { }
        private bool _isEvening;
        /// <summary>
        /// 指定对象是否需要后期动态绑定上下文。
        /// </summary>
        public bool IsEvening { set { _isEvening = value; } get { return _isEvening; } }
    }
}
