﻿/***
 * author:深度训练
 * blog:http://wangqingpei557.blog.51cto.com/
 * **/
using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace ContextModule
{
    /// <summary>
    /// 表示被标记为ContextOperationBaseAttribute特性的方法信息。
    /// </summary>
    public class ContextMethodInfo
    {
        public ContextMethodInfo(MethodInfo methodinfo, object postobject)
        {
            _methodinfo = methodinfo;
            _postobject = postobject;
        }
        private MethodInfo _methodinfo;
        /// <summary>
        /// 获取调用方法的全部信息
        /// </summary>
        public MethodInfo MethodInfo { get { return _methodinfo; } }
        private object _postobject;
        /// <summary>
        /// 获取调用方法的实例
        /// </summary>
        public object PostObject
        {
            get
            {
                return _postobject;
            }
        }
        /// <summary>
        /// 该方法在过滤链中是否已经处理过。
        /// </summary>
        public bool IsPost { get; set; }
    }
}
