﻿/***
 * author:深度训练
 * blog:http://wangqingpei557.blog.51cto.com/
 * **/
using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace ContextModule
{
    /// <summary>
    /// 上下绑定基类,强制派生类绑定到上下文。
    /// 逻辑上下文的策略构造都在这里进行。
    /// </summary>
    /// <typeparam name="T">受管理的上下文绑定对象类型，通常是ContextModuleBaseObject派生类。</typeparam>
    public class ContextModuleBaseObject<T> : ContextRuntime where T : class
    {
        /// <summary>
        /// 当前上下文绑定对象所绑定到的上下文物理对象实例。
        /// </summary>
        private ContextRuntime _contextRunTime;

        public ContextModuleBaseObject()
        {
            if (typeof(T).GetCustomAttributes(typeof(ContextEveningBoundAttribute), false) != null)
            {
                _IsEvening = true;
                return;
            }
            //前期静态绑定上下文
            if (ContextRuntime.CurrentContextRuntime == null)
                throw new Exception("上下文环境未能初始化,请检查您的代码入口是否启用了ContextRuntime对象。");
            _contextRunTime = ContextRuntime.CurrentContextRuntime;
            _InitContextHandler<T>();
        }
        /// <summary>
        /// 构造上下文的类过滤器、方法过滤器映射表。
        /// </summary>
        private void _InitContextHandler<ChildType>() where ChildType : class
        {
            //构造类过滤器
            ContextOperationBaseAttribute[] classattr =
                typeof(ChildType).GetCustomAttributes(typeof(ContextOperationBaseAttribute), false) as ContextOperationBaseAttribute[];
            if (classattr.Length > 0)
            {
                ContextOperationBaseAttribute joinoper = _JoinOperation(classattr);
                _contextRunTime.FilterMap.MapOperation(typeof(T).FullName, joinoper);
            }
            //构造方法过滤器
            foreach (MethodInfo method in typeof(ChildType).GetMethods())
            {
                ContextOperationBaseAttribute[] methodattr =
                    method.GetCustomAttributes(typeof(ContextOperationBaseAttribute), false) as ContextOperationBaseAttribute[];
                if (methodattr.Length <= 0)
                    continue;
                ContextOperationBaseAttribute joinoper = _JoinOperation(methodattr);
                _contextRunTime.FilterMap.MapOperation(string.Format("{0}.{1}", method.DeclaringType.FullName, method.Name), joinoper);
            }
        }
        internal bool _IsEvening { get; set; }
        /// <summary>
        /// 后期动态绑定上下文。
        /// </summary>
        internal void _EveningBoundChildClass<ChildType>() where ChildType : class
        {
            if (_contextRunTime != null)
                return;//说明之前已经进行过动态调用
            _contextRunTime = ContextRuntime.CurrentContextRuntime;//动态绑定当前运行时上下文
            _InitContextHandler<ChildType>();
        }

        private ContextOperationBaseAttribute _JoinOperation(ContextOperationBaseAttribute[] operationarray)
        {
            //必须对数组进行排序后才能连接
            for (int i = 0; i < operationarray.Length; i++)
            {
                for (int j = 0; j < i; j++)
                {
                    if (operationarray[j].OperationSort > operationarray[j + 1].OperationSort)
                    {
                        ContextOperationBaseAttribute oper = operationarray[j];
                        operationarray[j] = operationarray[j + 1];
                        operationarray[j + 1] = oper;
                    }
                }
            }
            ContextOperationBaseAttribute opernext = operationarray[0];
            for (int i = 1; i < operationarray.Length; i++)
            {
                opernext.NextOperation = operationarray[i];
                opernext = operationarray[i];//保持对当前循环对象的上级对象的引用。
            }
            return operationarray[0];
        }

        public MethodInfo GetMethodInfo(string methodname)
        {
            return this.GetType().GetMethod(methodname);
        }
        public override Guid InitPrimaryKey
        {
            get
            {
                return _contextRunTime.InitPrimaryKey;
            }
        }
        public override DateTime InitTime
        {
            get
            {
                return _contextRunTime.InitTime;
            }
        }
        public override object GetValue(object key)
        {
            return _contextRunTime.GetValue(key);
        }
        public override void SetValue(object key, object value)
        {
            _contextRunTime.SetValue(key, value);
        }
    }
}
