﻿/***
 * author:深度训练
 * blog:http://wangqingpei557.blog.51cto.com/
 * **/
using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace ConsoleApplication1.BLL
{
    [ContextModule.ContextEveningBound(IsEvening = true)]
    public class BLL_Order : ContextModule.ContextModuleBaseObject<BLL_Order>
    {
        DAL.DAL_Order dal_order = new DAL.DAL_Order();

        [ContextModule.ContextExceptionHandler(OperationSort = 1)]
        public Model.Model_Order InsertOrderSingle(Model.Model_Order ordermodel)
        {
            return ContextModule.ContextAction.PostMethod<DAL.DAL_Order, Model.Model_Order>(
                dal_order, dal_order.GetMethodInfo("InsertOrderSingle"), ordermodel);
        }
        [ContextModule.ContextExceptionHandler(OperationSort = 1)]
        public void SendOrder(Model.Model_Order ordermodel)
        {
            ContextModule.ContextAction.PostMethod<DAL.DAL_Order, object>(
               dal_order, dal_order.GetMethodInfo("SendOrder"), ordermodel);
        }
    }
}
