﻿/***
 * author:深度训练
 * blog:http://wangqingpei557.blog.51cto.com/
 * **/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using ConsoleApplication1.BLL;
using ConsoleApplication1.Model;

namespace ConsoleApplication1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            BLL.BLL_Order order = new BLL.BLL_Order();
            using (ContextModule.ContextRuntime.BeginContextRuntime())
            {
                Model.Model_Order ordermodel = new Model_Order() { OrderGuid = Guid.NewGuid(), OrderTime = DateTime.Now };
                Model.Model_Order resultmodel =
                    ContextModule.ContextAction.PostMethod<BLL.BLL_Order, Model.Model_Order>
                    (order, order.GetMethodInfo("InsertOrderSingle"), ordermodel);
                ContextModule.ContextAction.PostMethod<BLL.BLL_Order, object>(order, order.GetMethodInfo("SendOrder"), ordermodel);
            }
        }
    }
}
