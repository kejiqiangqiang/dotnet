﻿/***
 * author:深度训练
 * blog:http://wangqingpei557.blog.51cto.com/
 * **/
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1.DAL
{
    [ContextModule.ContextEveningBound(IsEvening = true)]
    public class DAL_Order : ContextModule.ContextModuleBaseObject<DAL_Order>
    {
        [ContextModule.ContextLogHandler(OperationSort = 1)]
        [ContextModule.ContextSecurityHanlder(OperationSort = 2)]
        public Model.Model_Order InsertOrderSingle(Model.Model_Order ordermodel)
        {
            return new Model.Model_Order() { OrderGuid = Guid.NewGuid(), OrderTime = DateTime.Now };
        }
        [ContextModule.ContextLogHandler(OperationSort = 1)]
        public void SendOrder(Model.Model_Order ordermodel)
        {
            Console.WriteLine("订单发送成功！");
        }
        [ContextModule.ContextLogHandler(OperationSort = 1)]
        public void UpdateOrderSingle()
        {
            Model.Model_Order ordermodel =
                ContextModule.ContextRuntime.CurrentContextRuntime.GetValue("updateorder") as Model.Model_Order;
        }
    }
}
